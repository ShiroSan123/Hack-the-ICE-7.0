// src/features/auth/components/OtpForm.tsx
import { useState } from 'react';

type Props = {
	onAuthSuccess: (user: any) => void;
};

type Step = 'enterRecipient' | 'enterCode';

export function OtpForm({ onAuthSuccess }: Props) {
	const [step, setStep] = useState<Step>('enterRecipient');
	const [recipient, setRecipient] = useState('');
	const [channel, setChannel] = useState<'sms' | 'email'>('sms');
	const [code, setCode] = useState('');
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState<string | null>(null);

	const requestCode = async () => {
		setLoading(true);
		setError(null);
		try {
			const res = await fetch('/api/auth/otp/request', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				credentials: 'include',
				body: JSON.stringify({ recipient, channel }),
			});

			if (!res.ok) {
				const data = await res.json().catch(() => null);
				throw new Error(data?.message || 'Не удалось отправить код');
			}

			setStep('enterCode');
		} catch (e: any) {
			setError(e.message);
		} finally {
			setLoading(false);
		}
	};

	const verifyCode = async () => {
		setLoading(true);
		setError(null);
		try {
			const res = await fetch('/api/auth/otp/verify', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				credentials: 'include',
				body: JSON.stringify({ recipient, code }),
			});

			if (!res.ok) {
				const data = await res.json().catch(() => null);
				throw new Error(data?.message || 'Неверный код');
			}

			const data = await res.json();

			// ВАЖНО: здесь дергаем onAuthSuccess — дальше родитель (AuthPage)
			// положит юзера в стор и сделает navigate('/dashboard')
			onAuthSuccess(data.user);
		} catch (e: any) {
			setError(e.message);
		} finally {
			setLoading(false);
		}
	};

	if (step === 'enterRecipient') {
		return (
			<div className="space-y-3">
				<label className="flex flex-col gap-1">
					<span className="text-sm font-medium">Телефон или почта</span>
					<input
						className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-black focus:outline-none"
						placeholder="+7 900 000-00-00 или email"
						value={recipient}
						onChange={(e) => setRecipient(e.target.value)}
					/>
				</label>

				<div className="flex gap-3 text-xs text-gray-600">
					<label className="flex items-center gap-1">
						<input
							type="radio"
							className="h-3 w-3"
							checked={channel === 'sms'}
							onChange={() => setChannel('sms')}
						/>
						SMS
					</label>
					<label className="flex items-center gap-1">
						<input
							type="radio"
							className="h-3 w-3"
							checked={channel === 'email'}
							onChange={() => setChannel('email')}
						/>
						Email
					</label>
				</div>

				<button
					type="button"
					onClick={requestCode}
					disabled={loading || !recipient}
					className="w-full rounded-md bg-black px-4 py-2 text-sm font-medium text-white hover:bg-gray-800 disabled:opacity-60"
				>
					{loading ? 'Отправляем код…' : 'Получить код'}
				</button>

				{error && <p className="text-xs text-red-500">{error}</p>}
			</div>
		);
	}

	return (
		<div className="space-y-3">
			<p className="text-sm text-gray-600">
				Мы отправили код на <span className="font-medium">{recipient}</span>
			</p>
			<input
				className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm tracking-[0.3em] text-center md:text-lg focus:border-black focus:outline-none"
				placeholder="• • • • • •"
				value={code}
				onChange={(e) => setCode(e.target.value)}
				maxLength={6}
			/>
			<button
				type="button"
				onClick={verifyCode}
				disabled={loading || code.length < 4}
				className="w-full rounded-md bg-black px-4 py-2 text-sm font-medium text-white hover:bg-gray-800 disabled:opacity-60"
			>
				{loading ? 'Проверяем…' : 'Подтвердить'}
			</button>
			{error && <p className="text-xs text-red-500">{error}</p>}
			<button
				type="button"
				onClick={() => setStep('enterRecipient')}
				className="w-full text-xs text-gray-500 hover:text-gray-700"
			>
				Изменить номер / почту
			</button>
		</div>
	);
}
