import {
	createContext,
	useContext,
	useEffect,
	useState,
	ReactNode,
} from 'react';
import { supabase } from '../../shared/lib/supabaseClient';

type AuthUser = {
	id: string;
	email?: string;
};

type AuthContextValue = {
	user: AuthUser | null;
	loading: boolean;
};

const AuthContext = createContext<AuthContextValue>({
	user: null,
	loading: true,
});

export function AuthProvider({ children }: { children: ReactNode }) {
	const [user, setUser] = useState<AuthUser | null>(null);
	const [loading, setLoading] = useState(true);

	useEffect(() => {
		const init = async () => {
			// 1) Проверяем текущую сессию
			const {
				data: { session },
				error,
			} = await supabase.auth.getSession();

			if (error) {
				console.warn('supabase.getSession error', error);
			}

			if (session?.user) {
				const u = session.user;
				setUser({
					id: u.id,
					email: u.email ?? undefined,
				});
			}

			setLoading(false);

			// 2) Подписка на любые изменения авторизации
			const {
				data: { subscription },
			} = supabase.auth.onAuthStateChange((_event, session) => {
				if (session?.user) {
					const u = session.user;
					setUser({
						id: u.id,
						email: u.email ?? undefined,
					});
				} else {
					setUser(null);
				}
			});

			return () => {
				subscription.unsubscribe();
			};
		};

		void init();
	}, []);

	return (
		<AuthContext.Provider value={{ user, loading }}>
			{children}
		</AuthContext.Provider>
	);
}

export const useAuth = () => useContext(AuthContext);
