import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/shared/ui/Button';
import {
	Card,
	CardContent,
	CardDescription,
	CardHeader,
	CardTitle,
} from '@/shared/ui/Card';
import { useAppStore } from '@/shared/store/useAppStore';
import { Heart } from 'lucide-react';
import { AuthModal } from './components/AuthModal';
import { useAuth } from './AuthContext';

export const AuthPage = () => {
	const { user: authUser, loading: authLoading } = useAuth();
	const { setUser } = useAppStore();
	const navigate = useNavigate();
	const [isAuthOpen, setIsAuthOpen] = useState(false);

	useEffect(() => {
		if (authLoading) return;
		if (!authUser) return;

		// мапим Supabase user в твой стор
		setUser({
			id: authUser.id,
			phone: '',
			region: 'xxxxxxxxx',
			category: 'pensioner',
			interests: [],
			role: 'self',
			simpleModeEnabled: true,
			name: authUser.email ?? 'Пользователь',
		});

		navigate('/dashboard', { replace: true });
	}, [authUser, authLoading, navigate, setUser]);

	const handleAuthSuccess = (userFromBackend: any) => {
		// этот путь — для OTP/Госуслуг, где ты сам возвращаешь user
		setUser({
			id: userFromBackend.id,
			phone: userFromBackend.phone ?? '',
			region: userFromBackend.region ?? 'xxxxxxxxx',
			category: userFromBackend.category ?? 'pensioner',
			interests: userFromBackend.interests ?? [],
			role: userFromBackend.role ?? 'self',
			simpleModeEnabled:
				userFromBackend.simpleModeEnabled ?? true,
			name: userFromBackend.name ?? 'Пользователь',
		});

		setIsAuthOpen(false);
		navigate('/dashboard');
	};

	return (
		<div className="min-h-screen bg-background flex items-center justify-center p-4">
			<Card className="w-full max-w-md">
				<CardHeader className="text-center">
					<div className="mx-auto w-16 h-16 rounded-full bg-primary flex items-center justify-center mb-4">
						<Heart className="w-10 h-10 text-primary-foreground" />
					</div>
					<CardTitle className="text-3xl">
						Добро пожаловать
					</CardTitle>
					<CardDescription className="text-lg">
						Социальный навигатор «Поддержка++»
					</CardDescription>
				</CardHeader>

				<CardContent className="space-y-4">
					<Button
						type="button"
						size="lg"
						className="w-full"
						onClick={() => setIsAuthOpen(true)}
					>
						Войти / Зарегистрироваться
					</Button>

					<p className="text-center text-sm text-muted-foreground">
						При первом входе будет создан новый профиль
					</p>
				</CardContent>
			</Card>

			{isAuthOpen && (
				<AuthModal
					onClose={() => setIsAuthOpen(false)}
					onAuthSuccess={handleAuthSuccess}
				/>
			)}
		</div>
	);
};
